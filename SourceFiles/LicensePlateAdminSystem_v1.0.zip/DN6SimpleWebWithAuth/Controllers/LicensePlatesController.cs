﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DN6SimpleWebWithAuth.Data;
using LicensePlateDataModels;
using LicensePlateDataLibrary;

namespace LicensePlateAdminSystem.Controllers
{
    public class LicensePlatesController : Controller
    {
        private readonly LicensePlateDataDbContext _context;

        public LicensePlatesController(LicensePlateDataDbContext context)
        {
            _context = context;
        }
        
        // GET: LicensePlates
        public async Task<IActionResult> Index()
        {
            return _context.LicensePlates != null ?
                        View(await _context.LicensePlates.ToListAsync()) :
                        Problem("Entity set 'ApplicationDbContext.LicensePlates'  is null.");
        }

        // GET: LicensePlates/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            //if (id == null || _context.LicensePlates == null)
            //{
            //    return NotFound();
            //}

            var licensePlateData = await _context.LicensePlates
                .FirstOrDefaultAsync(m => m.Id == id);
            if (licensePlateData == null)
            {
                return NotFound();
            }

            return View(licensePlateData);
        }

        // GET: LicensePlates/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: LicensePlates/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,IsProcessed,FileName,LicensePlateText,TimeStamp")] LicensePlate licensePlateData)
        {
            if (ModelState.IsValid)
            {
                _context.Add(licensePlateData);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(licensePlateData);
        }

        // GET: LicensePlates/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.LicensePlates == null)
            {
                return NotFound();
            }

            var licensePlateData = await _context.LicensePlates.FindAsync(id);
            if (licensePlateData == null)
            {
                return NotFound();
            }
            return View(licensePlateData);
        }

        // POST: LicensePlates/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,IsProcessed,FileName,LicensePlateText,TimeStamp")] LicensePlate licensePlateData)
        {
            if (id != licensePlateData.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(licensePlateData);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LicensePlateDataExists(licensePlateData.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(licensePlateData);
        }

        // GET: LicensePlates/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.LicensePlates == null)
            {
                return NotFound();
            }

            var licensePlateData = await _context.LicensePlates
                .FirstOrDefaultAsync(m => m.Id == id);
            if (licensePlateData == null)
            {
                return NotFound();
            }

            return View(licensePlateData);
        }

        // POST: LicensePlates/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.LicensePlates == null)
            {
                return Problem("Entity set 'ApplicationDbContext.LicensePlates'  is null.");
            }
            var licensePlateData = await _context.LicensePlates.FindAsync(id);
            if (licensePlateData != null)
            {
                _context.LicensePlates.Remove(licensePlateData);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool LicensePlateDataExists(int id)
        {
          return (_context.LicensePlates?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
