using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using LicensePlateProcessing.StorageAndFileProcessing;
using Azure.Messaging.ServiceBus;
using System.Text;

namespace LicensePlateProcessing
{
    public static class ProcessReviews
    {
        [FunctionName("ProcessReviews")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("Process Reviews started");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            var fileUrl = data.fileUrl;
            log.LogInformation($"File url posted for processing: {fileUrl}");

            var container = Environment.GetEnvironmentVariable("datalakeexportscontainer");
            var storageConnection = Environment.GetEnvironmentVariable("datalakeexportsconnection");

            var blobHelper = new BlobStorageHelper(storageConnection, container, log);
            var theBlob = await blobHelper.DownloadBlob(BlobStorageHelper.GetBlobNameFromURL((string)fileUrl, container));
            log.LogInformation($"Blob Data Retrieved with length: {theBlob.Length}");

            //parse the plate information
            log.LogInformation($"Parsing file: {fileUrl}");
            var plateData = CSVHelper.GetPlateDataFromCSV(theBlob);

            log.LogInformation($"Plate Data Retrieved {plateData.Count} plates");

            //add the service bus connection and clients
            var sbConnectionString = Environment.GetEnvironmentVariable("WriteOnlySBConnectionString");
            var sbQueueName = Environment.GetEnvironmentVariable("ServiceBusQueueName");
            var client =  new ServiceBusClient(sbConnectionString);
            var sender =  client.CreateSender(sbQueueName);

            // create a batch
            using ServiceBusMessageBatch messageBatch = await sender.CreateMessageBatchAsync();
            {
                try
                {
                    foreach (var p in plateData)
                    {
                        log.LogInformation($"Plate: {p.LicensePlateText}");

                        StringBuilder sb = new StringBuilder();
                        sb.Append("{");
                        sb.Append("\"fileName\":\"");
                        sb.Append(p.FileName);
                        sb.Append("\",\"licensePlateText\":\"");
                        sb.Append(p.LicensePlateText);
                        sb.Append("\",\"timeStamp\":\"");
                        sb.Append(p.TimeStamp.ToString());
                        sb.Append("\",\"exported\": false");
                        sb.Append("}");

                        var msg = sb.ToString();

                        if (!messageBatch.TryAddMessage(new ServiceBusMessage(msg)))
                        {
                            // if an exception occurs
                            throw new Exception($"Exception has occurred adding message {msg} to batch.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    //consider logging something more verbose to application insights
                    log.LogError($"{ex.Message}");
                }

                try
                {
                    await sender.SendMessagesAsync(messageBatch);
                    log.LogInformation($"Batch processed {messageBatch.Count} messages to the queue for manual plate review");
                }
                catch (Exception ex)
                {
                    //consider logging something more verbose to application insights
                    log.LogError($"Exception sending messages as batch: {ex.Message}");
                }
                finally
                {
                    //clean up resources
                    await sender.DisposeAsync();
                    await client.DisposeAsync();
                }
            }

            return new OkObjectResult("Processing Completed");
        }
    }
}
