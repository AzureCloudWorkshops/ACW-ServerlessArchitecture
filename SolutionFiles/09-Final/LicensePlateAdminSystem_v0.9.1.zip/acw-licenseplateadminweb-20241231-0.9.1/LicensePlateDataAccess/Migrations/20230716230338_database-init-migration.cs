﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LicensePlateDataAccess.Migrations
{
    public partial class databaseinitmigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
