﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LicensePlateDataAccess;
using LicensePlateModels;
using Microsoft.ApplicationInsights;
using Newtonsoft.Json;
using LicensePlateWebAdminSystem.Models;
using Azure.Messaging.ServiceBus;
using LicensePlateWebAdminSystem.CosmosLogic;

namespace LicensePlateWebAdminSystem.Controllers
{
    public class LicensePlatesController : Controller
    {
        private readonly LicensePlateDataDbContext _context;
        private readonly string _SASToken;
        private static string _queueConnectionString;
        private static string _queueName;
        private readonly TelemetryClient _telemetryClient;
        private static int MAX_WAIT_TIME_SECONDS = 20;
        private static string _cosmosEndpoint;
        private static string _cosmosAuthKey;
        private static string _cosmosDbId;
        private static string _cosmosContainer;

        public LicensePlatesController(LicensePlateDataDbContext context, TelemetryClient telemetryClient)
        {
            _context = context;
            _telemetryClient = telemetryClient;
            _SASToken = Environment.GetEnvironmentVariable("PlateImagesSASToken") ?? string.Empty;
            _queueConnectionString = Environment.GetEnvironmentVariable("ReadOnlySBConnectionString") ?? string.Empty;
            _queueName = Environment.GetEnvironmentVariable("ServiceBusQueueName") ?? string.Empty;
            _cosmosEndpoint = Environment.GetEnvironmentVariable("cosmosDBEndpointUrl") ?? string.Empty;
            _cosmosAuthKey = Environment.GetEnvironmentVariable("cosmosDBAuthorizationKey") ?? string.Empty;
            _cosmosContainer = Environment.GetEnvironmentVariable("cosmosDBContainerId") ?? string.Empty;
            _cosmosDbId = Environment.GetEnvironmentVariable("cosmosDBDatabaseId") ?? string.Empty;
        }

        // GET: LicensePlates
        public async Task<IActionResult> Index(string? success)
        {
            if (!string.IsNullOrWhiteSpace(success) && success.Equals("showsuccess"))
            {
                ViewBag.JavaScriptFunction = "notifyUserOfSuccess";
            }

            _telemetryClient.TrackEvent("LicensePlatesController.Index() called.");
            var plates = await _context.LicensePlates.ToListAsync();
            var count = plates?.Count() ?? 0;
            _telemetryClient.TrackTrace($"Current Plate count: {count}.");
            return count > 0 ?
                    View(plates) :
                    Problem("Entity set 'LicensePlateDataDbContext.LicensePlates'  is null.");
        }

        // GET: LicensePlates/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.LicensePlates == null)
            {
                return NotFound();
            }

            var licensePlate = await _context.LicensePlates
                .FirstOrDefaultAsync(m => m.Id == id);
            if (licensePlate == null)
            {
                return NotFound();
            }

            ViewBag.ImageURL = $"{licensePlate.FileName}?{_SASToken}";
            return View(licensePlate);
        }

        // GET: LicensePlates/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: LicensePlates/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,IsProcessed,FileName,LicensePlateText,TimeStamp")] LicensePlate licensePlate)
        {
            if (ModelState.IsValid)
            {
                _context.Add(licensePlate);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(licensePlate);
        }

        // GET: LicensePlates/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.LicensePlates == null)
            {
                return NotFound();
            }

            var licensePlate = await _context.LicensePlates.FindAsync(id);
            if (licensePlate == null)
            {
                return NotFound();
            }
            return View(licensePlate);
        }

        // POST: LicensePlates/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,IsProcessed,FileName,LicensePlateText,TimeStamp")] LicensePlate licensePlate)
        {
            if (id != licensePlate.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(licensePlate);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LicensePlateExists(licensePlate.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(licensePlate);
        }

        // GET: LicensePlates/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.LicensePlates == null)
            {
                return NotFound();
            }

            var licensePlate = await _context.LicensePlates
                .FirstOrDefaultAsync(m => m.Id == id);
            if (licensePlate == null)
            {
                return NotFound();
            }

            return View(licensePlate);
        }

        // POST: LicensePlates/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.LicensePlates == null)
            {
                return Problem("Entity set 'LicensePlateDataDbContext.LicensePlates'  is null.");
            }
            var licensePlate = await _context.LicensePlates.FindAsync(id);
            if (licensePlate != null)
            {
                _context.LicensePlates.Remove(licensePlate);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool LicensePlateExists(int id)
        {
            return (_context.LicensePlates?.Any(e => e.Id == id)).GetValueOrDefault();
        }


        // GET: LicensePlates/ReviewNextPlateFromQueue
        public async Task<IActionResult> ReviewNextPlateFromQueue()
        {
            var messageBody = string.Empty;
            var lpd = new LicensePlateQueueMessageData();
            try
            {
                if (string.IsNullOrWhiteSpace(_queueConnectionString) || string.IsNullOrWhiteSpace(_queueName))
                {
                    throw new ArgumentException("Ensure queue readonly/consumer connection string and queue name are set correctly" +
                        "in the environment variables and/or key vault.");
                }

                //create the QueueClient to query for just one message at a time:
                var queueClient = new ServiceBusClient(_queueConnectionString);
                var options = new ServiceBusReceiverOptions() { 
                    PrefetchCount = 0,
                    ReceiveMode = ServiceBusReceiveMode.ReceiveAndDelete
                };
                var receiver = queueClient.CreateReceiver(_queueName, options);

                var waitTime = TimeSpan.FromSeconds(MAX_WAIT_TIME_SECONDS);
                var msg = await receiver.ReceiveMessageAsync(waitTime);

                if (msg is null || msg?.Body is null)
                {
                    Console.WriteLine("No messages in the queue and wait time has elapsed");
                    return RedirectToAction(nameof(Index));
                }

                string body = msg.Body.ToString();
                Console.WriteLine($"Received: {body}");

                var plateData = JsonConvert.DeserializeObject<LicensePlateQueueMessageData>(body);

                if (string.IsNullOrWhiteSpace(plateData?.FileName))
                {
                    _telemetryClient.TrackException(new Exception("No data returned from the queue for processing"));
                    return RedirectToAction(nameof(Index));
                }
                //inject the sas token on the url
                var imageURL = $"{plateData?.FileName}?{_SASToken}";
                _telemetryClient.TrackTrace($"ImageURL: {imageURL}");

                //add the image url to the viewbag for display
                ViewBag.ImageURL = imageURL;

                //open the review page with the LicensePlateData
                return View(plateData);
            }
            catch (Exception ex)
            {
                _telemetryClient.TrackException(ex);
                return Problem(ex.Message);
            }
        }

        // POST: LicensePlates/UpdateCosmos/lpd object
        [HttpPost, ActionName("UpdateCosmos")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateCosmos([Bind("FileName,LicensePlateText,TimeStamp")] LicensePlateQueueMessageData licensePlateData)
        {
            var plateData = new Dictionary<string, string>();
            plateData.Add(licensePlateData.FileName, licensePlateData.LicensePlateText);
            _telemetryClient.TrackEvent("User updating plate", plateData);

            var cosmosHelper = new CosmosOperationsWeb(_cosmosEndpoint, _cosmosAuthKey, _cosmosDbId, _cosmosContainer, _telemetryClient);
            await cosmosHelper.UpdatePlatesForConfirmation(licensePlateData.FileName, licensePlateData.TimeStamp, licensePlateData.LicensePlateText);
            _telemetryClient.TrackTrace($"Completed processing for file {licensePlateData.FileName} with ts {licensePlateData.TimeStamp}");

            return RedirectToAction(nameof(Index), new { success = "showsuccess" });
        }
    }
}
