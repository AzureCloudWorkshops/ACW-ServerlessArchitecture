﻿using CsvHelper;
using LicensePlateDataModels;
using LicensePlateProcessingFunctions.CosmosLogic;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LicensePlateProcessingFunctions.StorageAndFileProcessing
{
    public class CSVHelper
    {
        public async Task<byte[]> CreateCSVStreamFromPlateData(IEnumerable<LicensePlateDataDocument> data)
        {
            using (var stream = new MemoryStream())
            {
                using (var textWriter = new StreamWriter(stream))
                {
                    using (var csv = new CsvWriter(textWriter, CultureInfo.InvariantCulture, false))
                    {
                        csv.WriteRecords(data.Select(ToLicensePlateData));
                        await textWriter.FlushAsync();
                        stream.Position = 0;
                        var bytes = stream.ToArray();
                        return bytes;
                    }
                }
            }
        }

        /// <summary>
        /// Used for mapping from a LicensePlateDataDocument object to a LicensePlateData object.
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        private static LicensePlateData ToLicensePlateData(LicensePlateDataDocument source)
        {
            return new LicensePlateData
            {
                FileName = source.fileName,
                LicensePlateText = source.licensePlateText,
                TimeStamp = source.timeStamp
            };
        }

        public static List<LicensePlateData> GetPlateDataFromCSV(byte[] csvFileBytes)
        {
            var plateData = new List<LicensePlateData>();

            using (var ms = new MemoryStream(csvFileBytes))
            {
                using (var reader = new StreamReader(ms))
                {
                    // Read file content.
                    while (reader.Peek() != -1)
                    {
                        var nextLineData = reader.ReadLine().Split(",");
                        if (nextLineData[0].Equals("filename", StringComparison.OrdinalIgnoreCase)) continue;
                        var lpd = new LicensePlateData();
                        lpd.FileName = nextLineData[0];
                        lpd.LicensePlateText = nextLineData[1];
                        lpd.TimeStamp = Convert.ToDateTime(nextLineData[2]);
                        plateData.Add(lpd);
                    }
                }
            }
            return plateData;
        }
    }
}
