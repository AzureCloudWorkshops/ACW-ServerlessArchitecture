﻿using LicensePlateDataAccess;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;


[assembly: FunctionsStartup(typeof(LicensePlateProcessingFunctions.Startup))]

namespace LicensePlateProcessingFunctions
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            //NOTE: Environment Variables come from Application Settings, not connection strings!
            string connectionString = Environment.GetEnvironmentVariable("LicensePlateDataDbConnection");
            builder.Services.AddDbContext<LicensePlateDataDbContext>(
            options => SqlServerDbContextOptionsExtensions.UseSqlServer(options, connectionString));
        }
    }
}
