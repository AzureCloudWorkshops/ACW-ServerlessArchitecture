using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using LicensePlateProcessingFunctions.StorageAndFileProcessing;
using LicensePlateDataAccess;
using Microsoft.EntityFrameworkCore;
using LicensePlateModels;
using System.Collections.Generic;

namespace LicensePlateProcessingFunctions
{
    public class ProcessImports
    {
        private readonly LicensePlateDataDbContext _context;

        public ProcessImports(LicensePlateDataDbContext context)
        {
            _context = context;
        }

        [FunctionName("ProcessImports")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("Process Imports Started");

            ////temp test (left this in for review purposes for the workshop only):
            //var test = await _context.LicensePlates.ToListAsync();
            //foreach (var t in test)
            //{
            //    log.LogInformation($"Plate: {t.LicensePlateText}");
            //}

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            var fileUrl = data.fileUrl;
            log.LogInformation($"File url posted for processing: {fileUrl}");

            var container = Environment.GetEnvironmentVariable("datalakeexportscontainer");
            var storageConnection = Environment.GetEnvironmentVariable("datalakeexportsconnection");

            var blobHelper = new BlobStorageHelper(storageConnection, container, log);
            var theBlob = await blobHelper.DownloadBlob(BlobStorageHelper.GetBlobNameFromURL((string)fileUrl, container));
            log.LogInformation($"Blob Data Retrieved with length: {theBlob.Length}");

            //parse the plate information
            log.LogInformation($"Parsing file: {fileUrl}");
            var plateData = CSVHelper.GetPlateDataFromCSV(theBlob);

            log.LogInformation($"Plate Data Retrieved {plateData.Count} plates");

            var plates = new List<LicensePlate>();
            foreach (var p in plateData)
            {
                log.LogInformation($"Import Plate: {p.LicensePlateText}");
                var plate = new LicensePlate();
                plate.FileName = p.FileName;
                plate.TimeStamp = p.TimeStamp;
                plate.LicensePlateText = p.LicensePlateText;
                plate.IsProcessed = false;
                plates.Add(plate);
            }

            log.LogInformation("Importing all plates to database and saving changes");
            _context.LicensePlates.AddRange(plates);
            await _context.SaveChangesAsync();

            log.LogInformation("Plates imported successfully");

            return new OkObjectResult("Processing Completed");
        }

        
    }
}
