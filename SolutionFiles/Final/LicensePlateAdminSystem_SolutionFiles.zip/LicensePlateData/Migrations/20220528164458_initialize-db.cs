﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LicensePlateDataLibrary.Migrations
{
    public partial class initializedb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
